<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Category extends Model
{
    use HasFactory;
    
    protected $fillable =['name','last_name','age','birthdate','CI','sex','email','emergency_contac','positions_id'];
    public function enumEstado() // Método para obtener las opciones del enum
    {
        return self::$sex;
    }
    public static $sex = [ // Nombre del enum en español (mayúsculas)
        'male' => 'Male',
        'female' => 'Female',
        
    ];
}
