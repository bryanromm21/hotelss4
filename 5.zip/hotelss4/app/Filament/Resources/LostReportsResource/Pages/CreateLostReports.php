<?php

namespace App\Filament\Resources\LostReportsResource\Pages;

use App\Filament\Resources\LostReportsResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateLostReports extends CreateRecord
{
    protected static string $resource = LostReportsResource::class;
}
